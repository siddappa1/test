# ES6-React
Code base for React with ES6+7
##  Build
- Run `npm install`
- install webpack globally by running `npm install webpack -g`
- install webpack-dev-server globally by running `npm install webpack -g`
- Run `webpack`

## Run
- Run `webpack-dev-server --content-base ./bin`

## Test
- Run `npm test`
